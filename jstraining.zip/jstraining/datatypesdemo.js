var a;
a=10;

var name;
name = "sundar";

var x = 25.0;

var y = true;

console.log(y);
console.log(name);