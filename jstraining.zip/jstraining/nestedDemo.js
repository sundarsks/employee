function main(){

    var a = 10;
    var b = 40;

    function sum(){
        console.log(a+b)
    }
    sum();

    var mulitiply =  function(){
        console.log(a*b)
    }
    mulitiply();

}

main();