var a = 100;
function greet () {
    var y = 200;
    console.log(24);

}

function goodbye(){
    console.log(a);
    //console.log(y)
}

greet();
goodbye();


 
function test(a,b){
if(typeof a == 'undefined'&& typeof b == 'undefined') {
    a=0;
    b=0;
    console.log(a+b);
}
   
}

test(20,30);
test(20);
