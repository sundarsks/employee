
//var a = 10;
//var welcome = function(){
  //  console.log("hi");
//}

//function greet() {
  //  console.log("HCL");
    //console.log(++a);
//}
//console.log(typeof greet);
//console.log(typeof welcome);
//welcome();
//console.log(++a);


function doSomething(a) {
    console.log(typeof a);
}
doSomething(10);

var welcome = function(){
    console.log("welcome to HCL");
}

doSomething(welcome);


var goodbyuser = function(){
    console.log("Thanks for visting");
}

doSomething(function(){console.log("In Office")})
